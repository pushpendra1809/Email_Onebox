def start_sync():
    
    print("IMAP sync started... (mocked)")
